# write a pp to take dstance in km and convert it into meters , centimertes and millimeteer
distance = int(input())
print("km in meter is",distance*1000)
print("km in centimeter is",distance*100000)
print("km in millimeter is",distance*1000000)