#Write a pp to find the base number x and an exponent y as input and calcuoate x raised to the power y

x = int(input())
y = int(input())
print(x**y)