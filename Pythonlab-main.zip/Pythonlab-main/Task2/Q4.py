# Wrtite a pp task the user for radius and calculate area and circumference of a circle

r = int(input())
print("Area: ",3.14*r*r)
print("circumference: ", 2*3.14*r)