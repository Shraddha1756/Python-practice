#Write  python program to calculate simple intersest and total amount using prinicpal , rate and time enetered by the user
p = int(input())
r = int(input())
t = int(input())
si = (p*r*t)/100
amount = p+si
print(si)
print(amount)