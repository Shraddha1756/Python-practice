# Write a pyhton program to find an average of two numbers entered by user.
a = int(input())
b = int(input())
medium = (a+b)/2
print("medium: ", medium)