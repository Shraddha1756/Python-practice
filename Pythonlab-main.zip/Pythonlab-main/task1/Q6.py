# Write a program to calculate the square of a number entered by the user
a = int(input())
print(a**2)