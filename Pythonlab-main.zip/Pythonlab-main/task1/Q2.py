# Write a P P to find remainder when number is divided by z
a = int(input())
z = int(input())
print("rem: ",a%z)