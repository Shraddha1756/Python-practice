#Using comparision operator to find out wheather 'a' given vraiable is greater than 'b' or not . take a = 34 and b = 80
a = 34 
b = 80
print(a>b)
print(a<b)
print(a>=b)
print(a<=b)
print(a==b)