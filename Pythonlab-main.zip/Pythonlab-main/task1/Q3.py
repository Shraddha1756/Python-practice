# check the typpe of variable assigned using input() function
print(type(input()))