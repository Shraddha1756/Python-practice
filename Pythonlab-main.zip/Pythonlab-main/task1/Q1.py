# Write  a python program to peform addition , subtraction, multiplication, subtraction, division of two numbers. also find quotient
a = int(input())
b = int(input())
print("Add: " ,a+b)
print("Sub: " ,a-b)
print("Mul: " ,a*b)
print("Div: " ,a/b)
print("quo: " ,a//b)


 
